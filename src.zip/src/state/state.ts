import React from "react";

export type AnswerType = {
    question: string
    answer: string
    correct: boolean
    correctAnswer: string
}
export type QuestionType = {
    category: string
    correct_answer: string
    difficulty: string
    incorrect_answers: Array<string>
    question: string
    type: string
}

export type QuestionItemType = {
    question: string
    answers: Array<string>
    userAnswer: AnswerType | undefined
    questionNum: number
    totalQuestions: number
}
export type StatePropsType = {
    questionItem: QuestionItemType
}
export type QuestionState = QuestionType & { answers: Array<string> }

export enum Difficulty {
    EASY = "easy",
    MEDIUM = "medium",
    HARD = "hard",
}

export const state: StatePropsType = {
    questionItem: {
        question: 'question',
        answers: ['answers', 'answers1', 'answers2'],
        userAnswer: {
            question: '',
            answer: 'ans',
            correct: true,
            correctAnswer: ''
        },
        questionNum: 1,
        totalQuestions: 10
    }

}

// export const state1 = {
//     questions: [
//         {
//             category: 'category',
//             correct_answer: 'correct_answer',
//             difficulty: 'easy',
//             incorrect_answers: ['incorrect_answers', 'incorrect_answers', 'incorrect_answers'],
//             question: 'question1',
//             type: 'type'
//         },
//         {
//             category: 'category',
//             correct_answer: 'correct_answer',
//             difficulty: 'easy',
//             incorrect_answers: ['incorrect_answers', 'incorrect_answers', 'incorrect_answers'],
//             question: 'question2',
//             type: 'type'
//         },
//     ]
//
// }

const date = {
    questions: [
        {
            "category": "My Category",
            "type": "multiple",
            "difficulty": "easy",
            "question": "Question?",
            "correct_answer": "Correct Answer",
            "incorrect_answers": [
                "Incorrect Answers",
                "Incorrect Answers",
                "Incorrect Answers"
            ]
        },
        {
            "category": "Science: Computers",
            "type": "multiple",
            "difficulty": "easy",
            "question": "If you were to code software in this language you&#039;d only be able to type 0&#039;s and 1&#039;s.",
            "correct_answer": "Binary",
            "incorrect_answers": [
                "JavaScript",
                "C++",
                "Python"
            ]
        },
        {
            "category": "Science & Nature",
            "type": "multiple",
            "difficulty": "easy",
            "question": "Which of the following blood vessels carries deoxygenated blood?",
            "correct_answer": "Pulmonary Artery",
            "incorrect_answers": [
                "Pulmonary Vein",
                "Aorta",
                "Coronary Artery"
            ]
        },
        {
            "category": "Entertainment: Video Games",
            "type": "multiple",
            "difficulty": "easy",
            "question": "In what year was Garry&#039;s Mod released as a standalone title on Valve&#039;s Steam distribution service?",
            "correct_answer": "2006",
            "incorrect_answers": [
                "2007",
                "2004",
                "2003"
            ]
        },
        {
            "category": "Entertainment: Music",
            "type": "multiple",
            "difficulty": "easy",
            "question": "Who is the lead singer of Green Day?",
            "correct_answer": "Billie Joe Armstrong",
            "incorrect_answers": [
                "Mike Dirnt",
                "Sean Hughes",
                "Tr&eacute; Cool"
            ]
        },
        {
            "category": "Entertainment: Music",
            "type": "multiple",
            "difficulty": "easy",
            "question": "&quot;The Singing Cowboy&quot; Gene Autry is credited with the first recording for all but which classic Christmas jingle?",
            "correct_answer": "White Christmas",
            "incorrect_answers": [
                "Frosty the Snowman",
                "Rudolph the Red-Nosed Reindeer",
                "Here Comes Santa Claus"
            ]
        },
        {
            "category": "General Knowledge",
            "type": "multiple",
            "difficulty": "easy",
            "question": "What is the Zodiac symbol for Gemini?",
            "correct_answer": "Twins",
            "incorrect_answers": [
                "Fish",
                "Scales",
                "Maiden"
            ]
        },
        {
            "category": "History",
            "type": "multiple",
            "difficulty": "easy",
            "question": "In what year was the M1911 pistol designed?",
            "correct_answer": "1911",
            "incorrect_answers": [
                "1907",
                "1899",
                "1917"
            ]
        },
        {
            "category": "Entertainment: Video Games",
            "type": "multiple",
            "difficulty": "easy",
            "question": "Who is the leader of the Brotherhood of Nod in the Command and Conquer series?",
            "correct_answer": "Kane",
            "incorrect_answers": [
                "Joseph Stalin",
                "CABAL",
                "Yuri"
            ]
        },
        {
            "category": "History",
            "type": "multiple",
            "difficulty": "easy",
            "question": "Who was the first American in space?",
            "correct_answer": "Alan Shephard",
            "incorrect_answers": [
                "Neil Armstrong",
                "John Glenn",
                "Jim Lovell"
            ]
        }
    ]
}